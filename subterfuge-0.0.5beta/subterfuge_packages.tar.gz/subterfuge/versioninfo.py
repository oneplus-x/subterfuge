#This file contains information pertaining to Subterfuge's current version.
#It can be imported into another python program

#Current Version Information
major_release_version = 5
minor_release_version = 0
initial_revision_number = 86
current_revision_number = 86

