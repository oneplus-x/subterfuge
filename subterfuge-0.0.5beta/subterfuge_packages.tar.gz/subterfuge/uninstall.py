import os

os.system('rm -rf /usr/share/subterfuge/')
os.system('rm -rf /bin/subterfuge')


