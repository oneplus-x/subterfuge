import os
print "No new files to download."
	#fix binary
#print "Downloading new files"
#os.system("wget kinozoa.com/files/subterfuge")
#os.system("chmod +x subterfuge")
#os.system("rm /bin/subterfuge")
#os.system("mv subterfuge /bin/")
